import ProductManager from "./productManager.js";

const producto = new ProductManager();

console.log(producto.getProduct());
//console.log(producto.addProduct('Producto prueba 1', 'Esto es un producto prueba', 200, 'SinImagen', 'ABC123', 25));
//console.log(producto.addProduct('Producto prueba 2', 'Esto es un producto prueba', 210, 'SinImagen', 'ABC456', 35));
//console.log(producto.addProduct('Producto prueba 3', 'Esto es un producto prueba', 220, 'SinImagen', 'ABC789', 30));
//console.log(producto.deleteProduct(3));
